package com.applettechnologies.firebaseurl.Common;

public class Config {
    public static final String STR_PUSH = "pushNotification";
    public static final String STR_KEY = "webURL";
    public static final String STR_MESSAGE = "message";
}
