package com.applettechnologies.firebaseurl;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.applettechnologies.firebaseurl.Common.Config;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private ProgressDialog dialog;

    private BroadcastReceiver mRegistrationBroadCastReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Config WebView
        webView = (WebView) findViewById(R.id.webViewBrowser);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient(){
            @Override
            public void onPageFinished(WebView view, String url) {
                if(dialog.isShowing())
                    dialog.dismiss();
            }
        });

        mRegistrationBroadCastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

                String message = intent.getStringExtra(Config.STR_MESSAGE);
                showNotification("My Online Pathshala", message);
            }
        };

        onNewIntent(getIntent());
    }

        @Override
        protected void onNewIntent(Intent intent){
            dialog = new ProgressDialog(this);
            if (intent.getStringArrayExtra(Config.STR_KEY) !=null)
            {
                dialog.show();
                dialog.setMessage("Please wait...");
                webView.loadUrl(intent.getStringExtra(Config.STR_KEY));
            }
        }

    private void showNotification(String title, String message) {
        Intent intent = new Intent(getBaseContext(),MainActivity.class);
        intent.putExtra(Config.STR_KEY,message);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(getBaseContext(),0,intent,PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(getBaseContext());
        builder.setAutoCancel(true)
                .setWhen(System.currentTimeMillis())
                .setDefaults(Notification.DEFAULT_ALL)
                .setSmallIcon(R.mipmap.ic_launcher_round)
                .setContentTitle(title)
                .setContentText(message)
                .setContentIntent(contentIntent);
        NotificationManager notificationManager = (NotificationManager)getBaseContext().getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(1,builder.build());

    }

    @Override
    protected void onPause() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mRegistrationBroadCastReceiver);
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadCastReceiver,new IntentFilter("registrationComplete"));
        LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadCastReceiver,new IntentFilter(Config.STR_PUSH));
    }
}
